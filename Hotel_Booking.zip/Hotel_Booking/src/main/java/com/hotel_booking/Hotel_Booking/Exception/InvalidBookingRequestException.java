package com.hotel_booking.Hotel_Booking.Exception;

@SuppressWarnings("serial")
public class InvalidBookingRequestException extends RuntimeException {
    public InvalidBookingRequestException(String message) {
        super(message);
    }
}
