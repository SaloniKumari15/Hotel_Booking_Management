package com.hotel_booking.Hotel_Booking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel_booking.Hotel_Booking.Exception.RoleAlreadyExistException;
import com.hotel_booking.Hotel_Booking.Respository.RoleRepository;

import com.hotel_booking.Hotel_Booking.entities.Role;
@Service
public class RoleService {
     @Autowired
	 private  RoleRepository roleRepository;
     public List<Role> getRoles() {
         return roleRepository.findAll();
     }

     public Role createRole(Role theRole) {
         String roleName = "ROLE_"+theRole.getName().toUpperCase();
         Role role = new Role(roleName);
         if (roleRepository.existsByName(roleName)){
             throw new RoleAlreadyExistException(theRole.getName()+" role already exists");
         }
         return roleRepository.save(role);
     }

     public void deleteRole(Long roleId) {
    	 Optional<Role> role = roleRepository.findById(roleId);
    	 if(role.isPresent()) {
          roleRepository.deleteById(roleId);
    	 }
     }

}
