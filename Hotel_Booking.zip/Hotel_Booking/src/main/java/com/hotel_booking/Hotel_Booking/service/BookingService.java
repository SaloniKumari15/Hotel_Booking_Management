package com.hotel_booking.Hotel_Booking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel_booking.Hotel_Booking.Exception.InvalidBookingRequestException;
import com.hotel_booking.Hotel_Booking.Exception.ResourceNotFoundException;
import com.hotel_booking.Hotel_Booking.Respository.BookingRepository;
import com.hotel_booking.Hotel_Booking.entities.BookedRoom;
import com.hotel_booking.Hotel_Booking.entities.Room;

@Service
public class BookingService {
	
    @Autowired
	private BookingRepository bookingRepository;
    @Autowired
    private RoomService roomService;
	public List<BookedRoom> getAllBookings() {
	    return bookingRepository.findAll();
	}
	public String saveBooking(Long roomId, BookedRoom bookingRequest) {
		 if (bookingRequest.getCheckOutDate().isBefore(bookingRequest.getCheckInDate())){
        throw new InvalidBookingRequestException("Check-in date must come before check-out date");
			
		 }
		Room room=roomService.getRoomById(roomId).get();
		List<BookedRoom> existingBookingList=room.getBookings();
		  boolean roomIsAvailable = roomIsAvailable(bookingRequest,existingBookingList);
		  if (roomIsAvailable){
	            room.addBooking(bookingRequest);
	            bookingRepository.save(bookingRequest);
	        }
		  else {
			  throw  new InvalidBookingRequestException("Sorry, This room is not available for the selected dates;");
		  }
		  return bookingRequest.getBookingConfirmationCode();
	}
	
	
	
	private boolean roomIsAvailable(BookedRoom bookingRequest, List<BookedRoom> existingBookingList) {
		return existingBookingList.stream()
                .noneMatch(existingBooking ->
                        bookingRequest.getCheckInDate().equals(existingBooking.getCheckInDate())
                                || bookingRequest.getCheckOutDate().isBefore(existingBooking.getCheckOutDate())
                                || (bookingRequest.getCheckInDate().isAfter(existingBooking.getCheckInDate())
                                && bookingRequest.getCheckInDate().isBefore(existingBooking.getCheckOutDate()))
                                || (bookingRequest.getCheckInDate().isBefore(existingBooking.getCheckInDate())

                                && bookingRequest.getCheckOutDate().equals(existingBooking.getCheckOutDate()))
                                || (bookingRequest.getCheckInDate().isBefore(existingBooking.getCheckInDate())

                                && bookingRequest.getCheckOutDate().isAfter(existingBooking.getCheckOutDate()))

                                || (bookingRequest.getCheckInDate().equals(existingBooking.getCheckOutDate())
                                && bookingRequest.getCheckOutDate().equals(existingBooking.getCheckInDate()))

                                || (bookingRequest.getCheckInDate().equals(existingBooking.getCheckOutDate())
                                && bookingRequest.getCheckOutDate().equals(bookingRequest.getCheckInDate()))
                );
	}
	
	public BookedRoom findByBookingConfirmationCode(String confirmationCode) {
      
		return bookingRepository.findByBookingConfirmationCode(confirmationCode)
                .orElseThrow(() -> new ResourceNotFoundException("No booking found with booking code :"+confirmationCode));

	}
	public void cancelBooking(Long bookingId) {
		 bookingRepository.deleteById(bookingId);
		
	}
	public List<BookedRoom> getBookingsByUserEmail(String email) {
		
		return bookingRepository.findByGuestEmail(email);
	}

}
