package com.hotel_booking.Hotel_Booking.Security.User;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.hotel_booking.Hotel_Booking.entities.User;
import com.hotel_booking.Hotel_Booking.Respository.UserRepository;
@Service
public class HotelUserDetailsService implements UserDetailsService {
    @Autowired
	private UserRepository userRepository;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		   User user = userRepository.findByEmail(username)
		              .orElseThrow(() -> new UsernameNotFoundException("User not found"));
		   return HotelUserDetails.buildUserDetails(user);
	}
}
