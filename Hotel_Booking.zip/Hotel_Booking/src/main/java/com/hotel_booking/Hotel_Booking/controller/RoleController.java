package com.hotel_booking.Hotel_Booking.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hotel_booking.Hotel_Booking.Exception.RoleAlreadyExistException;
import com.hotel_booking.Hotel_Booking.Response.RoleResponse;
import com.hotel_booking.Hotel_Booking.entities.Role;
import com.hotel_booking.Hotel_Booking.service.RoleService;
import static org.springframework.http.HttpStatus.FOUND;

@RestController
@RequestMapping("/roles")
public class RoleController {
	@Autowired
	private RoleService roleService;

	@GetMapping("/all-roles")
	public ResponseEntity<List<RoleResponse>> getAllRoles() {
		List<Role> roles = roleService.getRoles();
		List<RoleResponse> roleResponses = new ArrayList<>();
		for (Role role : roles) {
			RoleResponse roleResponse = new RoleResponse();
			roleResponse.setId(role.getId());
			roleResponse.setName(role.getName());
			roleResponses.add(roleResponse);
		}
		return new ResponseEntity<>(roleResponses, FOUND);
	}

	@PostMapping("/create-new-role")
	public ResponseEntity<String> createRole(@RequestBody Role theRole) {
		try {
			roleService.createRole(theRole);
			return ResponseEntity.ok("New role created successfully!");
		} catch (RoleAlreadyExistException re) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body(re.getMessage());

		}
	}

	@DeleteMapping("/delete/{roleId}")
	public void deleteRole(@PathVariable("roleId") Long roleId) {
		roleService.deleteRole(roleId);
	}
}