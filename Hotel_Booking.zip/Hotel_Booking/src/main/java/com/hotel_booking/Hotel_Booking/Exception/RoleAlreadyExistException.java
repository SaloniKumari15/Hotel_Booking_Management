package com.hotel_booking.Hotel_Booking.Exception;

@SuppressWarnings("serial")
public class RoleAlreadyExistException extends RuntimeException {
    public RoleAlreadyExistException(String message) {
        super(message);
    }
}