package com.hotel_booking.Hotel_Booking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hotel_booking.Hotel_Booking.Exception.UserAlreadyExistsException;
import com.hotel_booking.Hotel_Booking.Respository.RoleRepository;
import com.hotel_booking.Hotel_Booking.Respository.UserRepository;
import com.hotel_booking.Hotel_Booking.entities.Role;
import com.hotel_booking.Hotel_Booking.entities.User;

import jakarta.transaction.Transactional;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private RoleRepository roleRepository;

	public User registerUser(User user) {
		String enterEmailIdString = user.getEmail();
		Optional<User> existingUser = userRepository.findByEmail(enterEmailIdString);
		if (existingUser.isPresent()) {
			throw new UserAlreadyExistsException(user.getEmail() + " already exists");
		}
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		Role userRole = roleRepository.findById(2l).get();
		user.setRole(userRole);
		return userRepository.save(user);
	}

	public List<User> getUsers() {
		return userRepository.findAll();
	}

	@Transactional
	public void deleteUser(Long id) {
		Optional<User> theUser = userRepository.findById(id);
		if (theUser.isPresent()) {
			userRepository.deleteById(id);
		}

	}

	public User getUser(String email) {
		return userRepository.findByEmail(email).orElseThrow(() -> new UsernameNotFoundException("User not found"));
	}
}