package com.hotel_booking.Hotel_Booking.utility;

import java.sql.Blob;
import java.sql.SQLException;

import org.apache.tomcat.util.codec.binary.Base64;

public class CommonUtility {
   
	public static String blobToString(Blob photo) {
		
		byte[] photobyte=null;
		if(photo != null){
           try {
			photobyte= photo.getBytes(1, (int) photo.length());
		} catch (SQLException e) {
			e.printStackTrace();
		}
        }
		 String base64Photo = Base64.encodeBase64String(photobyte);
		return base64Photo;
	}
}
