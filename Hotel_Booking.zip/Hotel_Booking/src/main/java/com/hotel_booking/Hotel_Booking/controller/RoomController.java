package com.hotel_booking.Hotel_Booking.controller;

import java.math.BigDecimal;
import java.sql.Blob;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.hotel_booking.Hotel_Booking.Exception.ResourceNotFoundException;
import com.hotel_booking.Hotel_Booking.Response.RoomResponse;
import com.hotel_booking.Hotel_Booking.entities.Room;
import com.hotel_booking.Hotel_Booking.service.RoomService;
import com.hotel_booking.Hotel_Booking.utility.CommonUtility;

@RestController
@RequestMapping("/rooms")
public class RoomController {
	
    @Autowired 
	private RoomService roomService;
	@GetMapping("/all-rooms")
	public ResponseEntity<List<RoomResponse>> getAllRooms(){
		List<Room> rooms=roomService.getAllRooms();
		List<RoomResponse> roomResponses=new ArrayList<>();
		for(Room room:rooms) {
			RoomResponse roomResponse=new RoomResponse();
			roomResponse.setId(room.getId());
			roomResponse.setRoomType(room.getRoomType());
			roomResponse.setRoomPrice(room.getRoomPrice());
			Blob photoBlob=room.getPhoto();
			String base64Photo = CommonUtility.blobToString(photoBlob);
			roomResponse.setPhoto(base64Photo);
			roomResponses.add(roomResponse);
		}
	
		return ResponseEntity.ok(roomResponses);
		}
	
	@PostMapping("/add/new-room")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ResponseEntity<Room> addNewRoom(@RequestParam("photo") MultipartFile photo,
			                               @RequestParam("roomType") String roomType,
			                               @RequestParam("roomPrice") BigDecimal roomPrice){
		 Room savedRoom=roomService.addNewRoom(photo,roomType,roomPrice);
		return ResponseEntity.ok(savedRoom);
		
		
	}
	
	@DeleteMapping("/delete/{roomId}")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ResponseEntity<Void> deleteRoom(@PathVariable Long roomId){
		roomService.deleteRoom(roomId);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@PutMapping("update/{roomId}")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ResponseEntity<Void> updateRoom(@PathVariable Long roomId,
			@RequestParam(required = false)  String roomType,
            @RequestParam(required = false) BigDecimal roomPrice,
            @RequestParam(required = false) MultipartFile photo){
		    roomService.updateRoom(roomId,roomType,roomPrice,photo);
		    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		
	}

    @GetMapping("/room/{roomId}")
    public ResponseEntity<RoomResponse> getRoomById(@PathVariable Long roomId){
    	Optional<Room> theRoom = roomService.getRoomById(roomId);
    	 if(theRoom.isPresent()) {
    		RoomResponse response=new RoomResponse();
            response.setId(roomId);
            response.setRoomPrice(theRoom.get().getRoomPrice());
            response.setRoomType(theRoom.get().getRoomType());
            response.setPhoto(CommonUtility.blobToString(theRoom.get().getPhoto()));
            return  ResponseEntity.ok(response);
    	 }
    	 else {
    		 throw new ResourceNotFoundException("Room not found");
    	 }
    }
  
    @GetMapping("/available-rooms")
    public ResponseEntity<List<RoomResponse>> getAvailableRooms(@RequestParam("checkInDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)LocalDate checkInDate,
            @RequestParam("checkOutDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)LocalDate checkOutDate,
            @RequestParam("roomType") String roomType){
    	 List<Room> availableRooms=roomService.getAvailableRooms(checkInDate,checkOutDate,roomType);
    	 List<RoomResponse> roomResponses = new ArrayList<>();
    	 for (Room room : availableRooms){
    		 String photo=CommonUtility.blobToString(room.getPhoto());
    		 RoomResponse response=new RoomResponse();
    		 response.setId(room.getId());
             response.setRoomPrice(room.getRoomPrice());
             response.setRoomType(room.getRoomType());
             response.setPhoto(photo);
             roomResponses.add(response);
    	 }
    	  if(roomResponses.isEmpty()){
              return ResponseEntity.noContent().build();
          }else{
              return ResponseEntity.ok(roomResponses);
          }
    }
    @GetMapping("/room/types")
    public List<String> getRoomTypes() {
        return roomService.getAllRoomTypes();
    }

}
