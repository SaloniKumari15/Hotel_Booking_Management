package com.hotel_booking.Hotel_Booking.Exception;

@SuppressWarnings("serial")
public class InternalServerException extends RuntimeException {
    public InternalServerException(String message) {
        super(message);
    }
}