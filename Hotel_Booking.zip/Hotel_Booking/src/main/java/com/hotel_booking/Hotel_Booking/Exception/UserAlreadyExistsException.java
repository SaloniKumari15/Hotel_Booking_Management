package com.hotel_booking.Hotel_Booking.Exception;


@SuppressWarnings("serial")
public class UserAlreadyExistsException extends RuntimeException {
   public UserAlreadyExistsException(String message) {
   super(message);
   }
}
