package com.hotel_booking.Hotel_Booking.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.hotel_booking.Hotel_Booking.Exception.InternalServerException;
import com.hotel_booking.Hotel_Booking.Respository.RoomRepository;
import com.hotel_booking.Hotel_Booking.entities.Room;

import java.sql.Blob;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

@Service
public class RoomService {
    @Autowired
	private RoomRepository roomRepository;
	
	public List<Room> getAllRooms() {
		return roomRepository.findAll();
	}

	public Room addNewRoom(MultipartFile photo, String roomType, BigDecimal roomPrice) {
		Room room=new Room();
		room.setRoomType(roomType);
		room.setRoomPrice(roomPrice);
		if (!photo.isEmpty()){
            byte[] photoBytes=null;
			try {
				photoBytes = photo.getBytes();
			} catch (IOException e) {
				e.printStackTrace();
			}
            Blob photoBlob=null;
			try {
				photoBlob = new SerialBlob(photoBytes);
			} catch (SerialException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
            room.setPhoto(photoBlob);
        }
		return roomRepository.save(room);
	}

	public void deleteRoom(Long roomId) {
		 Optional<Room> room=roomRepository.findById(roomId);
		 if(room.isPresent()) {
			 roomRepository.deleteById(roomId);
		 }

	}

	public Room updateRoom(Long roomId, String roomType, BigDecimal roomPrice,MultipartFile photo) {
		 Optional<Room> room=roomRepository.findById(roomId);
		 if(room.isPresent()) {
			 if(roomType!=null) {
		     room.get().setRoomType(roomType);
			 }
			 if(roomPrice!=null) {
		     room.get().setRoomPrice(roomPrice);
			 }
		     if (photo!=null){
		            byte[] photoBytes=null;
					try {
						photoBytes = photo.getBytes();
					} catch (IOException e) {
						e.printStackTrace();
					}
		            Blob photoBlob=null;
					try {
						photoBlob = new SerialBlob(photoBytes);
					}  catch (SQLException ex) {
		                throw new InternalServerException("Fail updating room");
		            }
		     room.get().setPhoto(photoBlob);
		 }
		 }
		return roomRepository.save(room.get());
	}

	public Optional<Room> getRoomById(Long roomId) {
		return roomRepository.findById(roomId);
		
	}

	public List<Room> getAvailableRooms(LocalDate checkInDate, LocalDate checkOutDate, String roomType) {
		return roomRepository.findAvailableRoomsByDatesAndType(checkInDate, checkOutDate, roomType);
	}

	public List<String> getAllRoomTypes() {
		return roomRepository.findDistinctRoomTypes();
		
	}

}
