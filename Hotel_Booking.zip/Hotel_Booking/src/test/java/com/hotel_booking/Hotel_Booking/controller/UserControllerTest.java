package com.hotel_booking.Hotel_Booking.controller;


 
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.hotel_booking.Hotel_Booking.Response.UserResponse;
import com.hotel_booking.Hotel_Booking.entities.Role;
import com.hotel_booking.Hotel_Booking.entities.User;
import com.hotel_booking.Hotel_Booking.service.UserService;
 
 class UserControllerTest {
 
    @InjectMocks
    UserController userController;
 
    @Mock
    UserService userService;
 
    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
 
    // Test case for @GetMapping("/all")
    @Test
    void testGetUsers() {
        User user1 = new User();
        Role role=new Role();
        role.setName("User");
        user1.setEmail("user1@example.com");
        user1.setRole(role);
        User user2 = new User();
        user2.setEmail("user2@example.com");
        user2.setRole(role);
        when(userService.getUsers()).thenReturn(Arrays.asList(user1, user2));
 
        ResponseEntity<List<UserResponse>> response = userController.getUsers();
 
        assertEquals(2, response.getBody().size());
        verify(userService, times(1)).getUsers();
    }
 
    // Test case for @DeleteMapping("/delete/{userId}")
    @Test
    void testDeleteUser() {
        Long email = 1L;
 
        doNothing().when(userService).deleteUser(email);
 
        ResponseEntity<String> response = userController.deleteUser(email);
 
        assertEquals("User deleted successfully", response.getBody());
        verify(userService, times(1)).deleteUser(email);
    }
}