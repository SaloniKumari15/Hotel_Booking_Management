package com.hotel_booking.Hotel_Booking.controller;
 
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.hotel_booking.Hotel_Booking.Response.RoomResponse;
import com.hotel_booking.Hotel_Booking.entities.Room;
import com.hotel_booking.Hotel_Booking.service.RoomService;
 
class RoomControllerTest {
 
    @InjectMocks
    RoomController roomController;
 
    @Mock
    RoomService roomService;
 
    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
 
    // Test case for @DeleteMapping("/delete/{roomId}")
    @Test
     void testDeleteRoom() {
        Long roomId = 1L;
 
        roomController.deleteRoom(roomId);
 
        verify(roomService, times(1)).deleteRoom(roomId);
    }
 
    // Test case for @PutMapping("update/{roomId}")
    @Test
   void testUpdateRoom() {
        Room room = new Room();
        room.setId(1L);
        room.setRoomType("Single");
        room.setRoomPrice(BigDecimal.valueOf(100));
 
        MultipartFile photo = null;
 
        when(roomService.updateRoom(room.getId(), room.getRoomType(), room.getRoomPrice(), photo)).thenReturn(room);
 
        ResponseEntity<Void> response = roomController.updateRoom(room.getId(), room.getRoomType(), room.getRoomPrice(), photo);
 
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        verify(roomService, times(1)).updateRoom(room.getId(), room.getRoomType(), room.getRoomPrice(), photo);
    }
 
    // Test case for @GetMapping("/room/{roomId}")
    @Test
    public void testGetRoomById() {
        Room room = new Room();
        room.setId(1L);
        room.setRoomType("Single");
        room.setRoomPrice(BigDecimal.valueOf(100));
 
        when(roomService.getRoomById(room.getId())).thenReturn(Optional.of(room));
 
        ResponseEntity<RoomResponse> response = roomController.getRoomById(room.getId());
 
        assertEquals("Single", response.getBody().getRoomType());
        verify(roomService, times(1)).getRoomById(room.getId());
    }
 
    // Test case for @GetMapping("/available-rooms")
    @Test
     void testGetAvailableRooms() {
        Room room1 = new Room();
        room1.setId(1L);
        room1.setRoomType("Single");
        room1.setRoomPrice(BigDecimal.valueOf(100));
 
        Room room2 = new Room();
        room2.setId(2L);
        room2.setRoomType("Double");
        room2.setRoomPrice(BigDecimal.valueOf(200));
 
        LocalDate checkInDate = LocalDate.of(2022, 12, 1);
        LocalDate checkOutDate = LocalDate.of(2022, 12, 10);
        String roomType = "Single";
 
        when(roomService.getAvailableRooms(checkInDate, checkOutDate, roomType)).thenReturn(Arrays.asList(room1, room2));
 
        ResponseEntity<List<RoomResponse>> response = roomController.getAvailableRooms(checkInDate, checkOutDate, roomType);
 
        assertEquals(2, response.getBody().size());
        verify(roomService, times(1)).getAvailableRooms(checkInDate, checkOutDate, roomType);
    }
}