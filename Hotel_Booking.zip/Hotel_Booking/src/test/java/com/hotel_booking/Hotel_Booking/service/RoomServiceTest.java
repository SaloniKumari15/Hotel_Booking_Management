package com.hotel_booking.Hotel_Booking.service;
 
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
 
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

import java.util.Optional;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;
import com.hotel_booking.Hotel_Booking.Respository.RoomRepository;
import com.hotel_booking.Hotel_Booking.entities.Room;
 
class RoomServiceTest {
 
    @Mock
    private RoomRepository roomRepository;
 
    @InjectMocks
    private RoomService roomService;
 
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
 
    @Test
     void testAddNewRoom() {
        // Arrange
        String roomType = "Single";
        BigDecimal roomPrice = BigDecimal.valueOf(100);
        MultipartFile photo = new MockMultipartFile("photo", new byte[]{});
        Room room = new Room();
        room.setRoomType(roomType);
        room.setRoomPrice(roomPrice);

        when(roomRepository.save(any(Room.class))).thenReturn(room);
 
        // Act
        Room savedRoom = roomService.addNewRoom(photo, roomType, roomPrice);
 
        // Assert
        assertNotNull(savedRoom);
        assertEquals(roomType, savedRoom.getRoomType());
        assertEquals(roomPrice, savedRoom.getRoomPrice());
    }
 
    @Test
   void testDeleteRoom() {
        // Arrange
        Long roomId = 1L;
        Room room = new Room();
        when(roomRepository.findById(roomId)).thenReturn(Optional.of(room));
 
        // Act
        roomService.deleteRoom(roomId);
 
        // Assert
        verify(roomRepository, times(1)).deleteById(roomId);
    }
 
    @Test
     void testUpdateRoom() throws IOException, SQLException {
        // Arrange
        Long roomId = 1L;
        String roomType = "Single";
        BigDecimal roomPrice = BigDecimal.valueOf(100);
        MultipartFile photo = new MockMultipartFile("photo", new byte[]{});
        Room room = new Room();
        when(roomRepository.findById(roomId)).thenReturn(Optional.of(room));
  
        room.setRoomType(roomType);
        room.setRoomPrice(roomPrice);
        when(roomRepository.save(any(Room.class))).thenReturn(room);
 
        // Act
        Room updatedRoom = roomService.updateRoom(roomId, roomType, roomPrice, photo);
 
        // Assert
        assertNotNull(updatedRoom);
        assertEquals(roomType, updatedRoom.getRoomType());
        assertEquals(roomPrice, updatedRoom.getRoomPrice());
    }
 
    
}