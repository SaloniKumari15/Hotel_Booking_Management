package com.hotel_booking.Hotel_Booking.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;
 
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
 
import com.hotel_booking.Hotel_Booking.Exception.InvalidBookingRequestException;
import com.hotel_booking.Hotel_Booking.Respository.BookingRepository;
import com.hotel_booking.Hotel_Booking.entities.BookedRoom;
import com.hotel_booking.Hotel_Booking.entities.Room;
 
class BookingServiceTest {
 
    @Mock
    private BookingRepository bookingRepository;
 
    @Mock
    private RoomService roomService;
 
    @InjectMocks
    private BookingService bookingService;
 
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
 
    @Test
    void testSaveBooking_WithValidBookingRequest_Success() {
        // Arrange
        Long roomId = 1L;
        BookedRoom bookingRequest = new BookedRoom();
        bookingRequest.setCheckInDate(LocalDate.of(2024, 4, 1));
        bookingRequest.setCheckOutDate(LocalDate.of(2024, 4, 3));
 
        Room room = new Room();
        List<BookedRoom> existingBookingList = new ArrayList<>();
        room.setBookings(existingBookingList);
        when(roomService.getRoomById(roomId)).thenReturn(Optional.of(room));
        when(bookingRepository.save(bookingRequest)).thenReturn(bookingRequest);
 
        // Act
        String confirmationCode = bookingService.saveBooking(roomId, bookingRequest);
 
        // Assert
        assertNotNull(confirmationCode);
        assertEquals(bookingRequest.getBookingConfirmationCode(), confirmationCode);
    }
 
    @Test
   void testSaveBooking_WithInvalidBookingRequest_ExceptionThrown() {
        // Arrange
        Long roomId = 1L;
        BookedRoom bookingRequest = new BookedRoom();
        bookingRequest.setCheckInDate(LocalDate.of(2025, 4, 9));
        bookingRequest.setCheckOutDate(LocalDate.of(2024, 4, 9));// Check-in date after check-out date
 
        // Act & Assert
        assertThrows(InvalidBookingRequestException.class, () -> bookingService.saveBooking(roomId, bookingRequest));
    }
 
}