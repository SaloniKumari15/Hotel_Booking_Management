package com.hotel_booking.Hotel_Booking.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.hotel_booking.Hotel_Booking.Exception.UserAlreadyExistsException;
import com.hotel_booking.Hotel_Booking.Respository.RoleRepository;
import com.hotel_booking.Hotel_Booking.Respository.UserRepository;
import com.hotel_booking.Hotel_Booking.entities.Role;
import com.hotel_booking.Hotel_Booking.entities.User;

class UserServiceTest {

    @InjectMocks
    UserService userService;

    @Mock
    UserRepository userRepository;

    @Mock
    RoleRepository roleRepository;

    @Mock
    PasswordEncoder passwordEncoder;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
   void testGetUsers() {
        User user = new User();
        user.setId(1L);
        user.setFirstName("Saloni");
        user.setLastName("Gupta");
        user.setEmail("saloni@example.com");
        user.setRole(new Role("ROLE_USER"));

        when(userRepository.findAll()).thenReturn(Arrays.asList(user));

        List<User> users = userService.getUsers();

        assertEquals(1, users.size());
        assertEquals("Saloni", users.get(0).getFirstName());
    }

    @Test
    void testRegisterUser() {
        User user = new User();
        user.setId(1L);
        user.setFirstName("Saloni");
        user.setLastName("Gupta");
        user.setEmail("saloni@example.com");
        user.setPassword("password");
        user.setRole(new Role("ROLE_USER"));

        when(userRepository.findByEmail(user.getEmail())).thenReturn(Optional.empty());
        when(passwordEncoder.encode(user.getPassword())).thenReturn("encodedPassword");
        when(roleRepository.findById(2L)).thenReturn(Optional.of(new Role("ROLE_USER")));
        when(userRepository.save(user)).thenReturn(user);

        User registeredUser = userService.registerUser(user);

        assertEquals("Saloni", registeredUser.getFirstName());
        assertEquals("encodedPassword", registeredUser.getPassword());
    }

    @Test
    void testRegisterUserAlreadyExists() {
        User user = new User();
        user.setId(1L);
        user.setFirstName("Saloni");
        user.setLastName("Gupta");
        user.setEmail("saloni@example.com");
        user.setPassword("password");
        user.setRole(new Role("ROLE_USER"));

        when(userRepository.findByEmail(user.getEmail())).thenReturn(Optional.of(user));

        assertThrows(UserAlreadyExistsException.class, () -> userService.registerUser(user));
    }

    @Test
    void testDeleteUser() {
        User user = new User();
        user.setId(1L);

        when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));

        userService.deleteUser(user.getId());
    }

    @Test
     void testGetUser() {
        User user = new User();
        user.setId(1L);
        user.setFirstName("Saloni");
        user.setLastName("Gupta");
        user.setEmail("saloni@example.com");
        user.setRole(new Role("ROLE_USER"));

        when(userRepository.findByEmail(user.getEmail())).thenReturn(Optional.of(user));

        User fetchedUser = userService.getUser(user.getEmail());

        assertEquals("Saloni", fetchedUser.getFirstName());
    }
}