package com.hotel_booking.Hotel_Booking.controller;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.hotel_booking.Hotel_Booking.Response.RoleResponse;
import com.hotel_booking.Hotel_Booking.entities.Role;
import com.hotel_booking.Hotel_Booking.service.RoleService;
 
class RoleControllerTest {
 
    @InjectMocks
    RoleController roleController;
 
    @Mock
    RoleService roleService;
 
    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
 
    // Test case for @GetMapping("/all-roles")
    @Test
     void testGetAllRoles() {
        Role role1 = new Role("ROLE_ADMIN");
        Role role2 = new Role("ROLE_USER");
 
        when(roleService.getRoles()).thenReturn(Arrays.asList(role1, role2));
 
        ResponseEntity<List<RoleResponse>> response = roleController.getAllRoles();
 
        assertEquals(2, response.getBody().size());
        verify(roleService, times(1)).getRoles();
    }
 
    // Test case for @PostMapping("/create-new-role")
    @Test
   void testCreateRole() {
        Role role = new Role("ROLE_ADMIN");
 
        when(roleService.createRole(role)).thenReturn(role);
 
        ResponseEntity<String> response = roleController.createRole(role);
 
        assertEquals("New role created successfully!", response.getBody());
        verify(roleService, times(1)).createRole(role);
    }
 
    // Test case for @DeleteMapping("/delete/{roleId}")
    @Test
     void testDeleteRole() {
        Long roleId = 1L;
 
        doNothing().when(roleService).deleteRole(roleId);
 
        roleController.deleteRole(roleId);
 
        verify(roleService, times(1)).deleteRole(roleId);
    }
}