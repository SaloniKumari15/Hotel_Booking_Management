package com.hotel_booking.Hotel_Booking.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.mockito.ArgumentMatchers.any;
import com.hotel_booking.Hotel_Booking.Exception.RoleAlreadyExistException;
import com.hotel_booking.Hotel_Booking.Respository.RoleRepository;
import com.hotel_booking.Hotel_Booking.entities.Role;

 class RoleServiceTest {

    @InjectMocks
    RoleService roleService;

    @Mock
    RoleRepository roleRepository;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
     void testGetRoles() {
        Role role = new Role("ROLE_USER");

        when(roleRepository.findAll()).thenReturn(Arrays.asList(role));

        List<Role> roles = roleService.getRoles();

        assertEquals(1, roles.size());
        assertEquals("ROLE_USER", roles.get(0).getName());
    }

  
    @Test
    void testCreateRole() {
        String roleName = "user";
        Role role = new Role(roleName);
        Role savedRole = new Role("ROLE_" + roleName.toUpperCase());

        // When
        when(roleRepository.existsByName(savedRole.getName())).thenReturn(false);
        when(roleRepository.save(any(Role.class))).thenReturn(savedRole);

        // Then
        Role createdRole = roleService.createRole(role);

        // Verify
        assertEquals(savedRole.getName(), createdRole.getName());
    }
    @Test
     void testCreateRoleAlreadyExists() {
        Role role = new Role("user");

        when(roleRepository.existsByName("ROLE_USER")).thenReturn(true);

        assertThrows(RoleAlreadyExistException.class, () -> roleService.createRole(role));
    }

    @Test
     void testDeleteRole() {
        Role role = new Role("ROLE_USER");
        role.setId(1L);

        when(roleRepository.findById(role.getId())).thenReturn(Optional.of(role));

        roleService.deleteRole(role.getId());
    }
}