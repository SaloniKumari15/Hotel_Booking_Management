package com.hotel_booking.Hotel_Booking.entities;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

 class RoomTest {

    @Test
   void testAddBooking() {
        Room room = new Room();
        BookedRoom booking = new BookedRoom();
        room.addBooking(booking);

        assertEquals(1, room.getBookings().size());
        assertEquals(room, booking.getRoom());
        assertTrue(room.isBooked());
        assertNotNull(booking.getBookingConfirmationCode());
    }

    @Test
    void testSetAndGetRoomType() {
        Room room = new Room();
        String expectedType = "Deluxe";
        room.setRoomType(expectedType);
        assertEquals(expectedType, room.getRoomType());
    }

    @Test
     void testSetAndGetRoomPrice() {
        Room room = new Room();
        BigDecimal expectedPrice = new BigDecimal("100.00");
        room.setRoomPrice(expectedPrice);
        assertEquals(expectedPrice, room.getRoomPrice());
    }

    
}
