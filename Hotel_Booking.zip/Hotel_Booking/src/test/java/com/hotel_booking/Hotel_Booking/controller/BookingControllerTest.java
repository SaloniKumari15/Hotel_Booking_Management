package com.hotel_booking.Hotel_Booking.controller;
 
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.hotel_booking.Hotel_Booking.Response.BookingResponse;
import com.hotel_booking.Hotel_Booking.entities.BookedRoom;
import com.hotel_booking.Hotel_Booking.entities.Room;
import com.hotel_booking.Hotel_Booking.service.BookingService;
import com.hotel_booking.Hotel_Booking.service.RoomService;

class BookingControllerTest {
 
    @InjectMocks
    BookingController bookingController;
 
    @Mock
    BookingService bookingService;
 
    @Mock
    RoomService roomService;
 
    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
 
    // Test case for @GetMapping("/all-bookings")
    @Test
     void testGetAllBookings() {
        Room testRoom = new Room();
        testRoom.setId(1L);
        testRoom.setRoomType("Single");
        BookedRoom booking1 = new BookedRoom();
        booking1.setRoom(testRoom);
        booking1.setBookingConfirmationCode("CONFIRM1");
        BookedRoom booking2 = new BookedRoom();
        booking2.setRoom(testRoom);
        booking2.setBookingConfirmationCode("CONFIRM2");
 
        when(bookingService.getAllBookings()).thenReturn(Arrays.asList(booking1, booking2));
        when(roomService.getRoomById(anyLong())).thenReturn(Optional.of(testRoom));
 
        ResponseEntity<List<BookingResponse>> response = bookingController.getAllBookings();
 
        assertEquals(2, response.getBody().size());
        assertEquals("CONFIRM1", response.getBody().get(0).getBookingConfirmationCode());
        assertEquals("CONFIRM2", response.getBody().get(1).getBookingConfirmationCode());
        verify(bookingService, times(1)).getAllBookings();
    }
 
    // Test case for @PostMapping("/room/{roomId}/booking")
    @Test
     void testSaveBooking() {
        Long roomId = 1L;
        BookedRoom booking = new BookedRoom();
 
        when(bookingService.saveBooking(roomId, booking)).thenReturn("CONFIRM1");
 
        ResponseEntity<?> response = bookingController.saveBooking(roomId, booking);
 
        assertEquals("Room booked successfully, Your booking confirmation code is :CONFIRM1", response.getBody());
        verify(bookingService, times(1)).saveBooking(roomId, booking);
    }
 
    // Test case for @GetMapping("/confirmation/{confirmationCode}")
    @Test
     void testGetBookingByConfirmationCode() {
        Room testRoom = new Room();
        testRoom.setId(1L);
        String confirmationCode = "CONFIRM1";
        BookedRoom booking = new BookedRoom();
        booking.setBookingConfirmationCode(confirmationCode);
        booking.setRoom(testRoom);
 
        when(bookingService.findByBookingConfirmationCode(confirmationCode)).thenReturn(booking);
        when(roomService.getRoomById(anyLong())).thenReturn(Optional.of(testRoom));
 
        ResponseEntity<?> response = bookingController.getBookingByConfirmationCode(confirmationCode);
 
        verify(bookingService, times(1)).findByBookingConfirmationCode(confirmationCode);
    }
 
    // Test case for @DeleteMapping("/booking/{bookingId}/delete")
    @Test
     void testCancelBooking() {
        Long bookingId = 1L;
 
        doNothing().when(bookingService).cancelBooking(bookingId);
 
        bookingController.cancelBooking(bookingId);
 
        verify(bookingService, times(1)).cancelBooking(bookingId);
    }
 
    // Test case for @GetMapping("/user/{email}/bookings")
    @Test
    void testGetBookingsByUserEmail() {
        Room testRoom = new Room();
        testRoom.setId(1L);
        String email = "user1@example.com";
        BookedRoom booking1 = new BookedRoom();
        booking1.setGuestEmail(email);
        booking1.setRoom(testRoom);
        BookedRoom booking2 = new BookedRoom();
        booking2.setGuestEmail(email);
        booking2.setRoom(testRoom);
 
        when(bookingService.getBookingsByUserEmail(email)).thenReturn(Arrays.asList(booking1, booking2));
        when(roomService.getRoomById(anyLong())).thenReturn(Optional.of(testRoom));
 
        ResponseEntity<List<BookingResponse>> response = bookingController.getBookingsByUserEmail(email);
 
        assertEquals(2, response.getBody().size());
        verify(bookingService, times(1)).getBookingsByUserEmail(email);
    }
}