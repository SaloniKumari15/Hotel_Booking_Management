package com.hotel_booking.Hotel_Booking.entities;



import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class BookedRoomTest {

    @Test
   void testCalculateTotalNumberOfGuest() {
        BookedRoom bookedRoom = new BookedRoom();
        bookedRoom.setNumOfAdults(2);
        bookedRoom.setNumOfChildren(3);
        assertEquals(5, bookedRoom.getTotalNumOfGuest());
    }

    @Test
    void testSetNumOfAdults() {
        BookedRoom bookedRoom = new BookedRoom();
        bookedRoom.setNumOfAdults(2);
        assertEquals(2, bookedRoom.getNumOfAdults());
        assertEquals(2, bookedRoom.getTotalNumOfGuest());
    }

    @Test
     void testSetNumOfChildren() {
        BookedRoom bookedRoom = new BookedRoom();
        bookedRoom.setNumOfChildren(3);
        assertEquals(3, bookedRoom.getNumOfChildren());
        assertEquals(3, bookedRoom.getTotalNumOfGuest());
    }

    @Test
    void testSetBookingConfirmationCode() {
        BookedRoom bookedRoom = new BookedRoom();
        bookedRoom.setBookingConfirmationCode("CONFIRM123");
        assertEquals("CONFIRM123", bookedRoom.getBookingConfirmationCode());
    }
}

